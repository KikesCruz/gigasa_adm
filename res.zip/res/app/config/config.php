<?php 
define('APP', dirname(dirname(__FILE__))); //rutas de carpetas
define('URL', 'http://www.gigasa-admin.com/'); // directorio de proyecto