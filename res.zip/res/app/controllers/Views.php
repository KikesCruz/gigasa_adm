<?php 
class Views extends Control {
    public function inicio(){
       $datos = [
        "title" => "Admin Gigasa"
       ];

       $this -> load_view('inicio',$datos);
    }

    public function login(){
        $datos = [
         "title" => "Admin Gigasa"
        ];
 
        $this -> load_view('login',$datos);
     }

    public function update($id){
        echo "Update view" .$id;
    }
}