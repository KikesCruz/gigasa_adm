<?php require_once APP . '/views/inc/header.php' ?>

<div class="container-fluid bg-light py-5">
  <div class="container">
    <h1 class="display-4">Welcome!!!</h1>
  </div>
</div>

<?php require_once APP .'/views/inc/footer.php'; ?>